import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Check, Star } from "lucide-react";

const AFFILIATE_LINK = "https://myprostadine24.com/text.php#aff=Lucass123";

export default function Home() {
  const [showCookieModal, setShowCookieModal] = useState(true);

  useEffect(() => {
    // Check if user has already made a choice
    const cookieChoice = localStorage.getItem("cookieChoice");
    if (cookieChoice) {
      setShowCookieModal(false);
    }
  }, []);

  const handleCookieChoice = () => {
    localStorage.setItem("cookieChoice", "true");
    setShowCookieModal(false);
    // Redirect to affiliate link
    window.location.href = AFFILIATE_LINK;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 text-white">
      {/* Cookie Modal */}
      {showCookieModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white text-slate-900 rounded-lg shadow-2xl p-8 max-w-md mx-4">
            <h3 className="text-xl font-bold mb-3">Cookie Consent</h3>
            <p className="text-sm text-slate-600 mb-6">
              We use cookies to enhance your experience and analyze site usage. By continuing, you accept our cookie policy.
            </p>
            <div className="flex gap-3">
              <Button
                onClick={handleCookieChoice}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
              >
                Accept
              </Button>
              <Button
                onClick={handleCookieChoice}
                variant="outline"
                className="flex-1 border-slate-300 text-slate-900 hover:bg-slate-100"
              >
                Decline
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="bg-slate-900/80 backdrop-blur-md border-b border-slate-700 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-blue-400">Prostadine</div>
          <div className="flex gap-6 text-sm">
            <a href="#benefits" className="hover:text-blue-400 transition">
              Benefits
            </a>
            <a href="#ingredients" className="hover:text-blue-400 transition">
              Ingredients
            </a>
            <a href="#pricing" className="hover:text-blue-400 transition">
              Pricing
            </a>
            <a href="#faq" className="hover:text-blue-400 transition">
              FAQ
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-20 pb-32">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500 rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="text-sm text-blue-400 font-semibold mb-4">
                August 2022 - New Scientific Discovery
              </div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
                This Cold Drink Might Trigger Your Prostate
              </h1>
              <p className="text-xl text-slate-300 mb-8">
                Here's one tip that can help you maintain a healthy prostate well into old age
              </p>
              <Button
                onClick={handleCookieChoice}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-lg"
              >
                Order Now
              </Button>
            </div>

            <div className="relative">
              <div className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-2xl p-8 border border-blue-400/30">
                <div className="text-center">
                  <div className="text-6xl mb-4">💧</div>
                  <h3 className="text-2xl font-bold mb-4">Prostadine Formula</h3>
                  <p className="text-slate-300">
                    9 Natural Ingredients Working in Perfect Synergy
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">
            Scientists Discover The Real Root Cause Of Prostate Problems
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-lg text-slate-300 mb-6">
                A recent Harvard study draws attention to the hard water in the US which contains toxic minerals that can create a dangerous buildup inside the body if consumed for a longer period of time.
              </p>
              <p className="text-lg text-slate-300 mb-6">
                As it turns out, hard water is found in the majority of US areas and, unfortunately, the government just closes its eyes on the fact that millions of Americans have improper tap water caused by poor and aging water pipe infrastructure.
              </p>
              <p className="text-lg text-blue-400 font-semibold">
                That's why we created Prostadine
              </p>
            </div>

            <div className="bg-gradient-to-br from-red-500/10 to-orange-500/10 rounded-2xl p-8 border border-red-400/30">
              <h3 className="text-2xl font-bold mb-4">The Solution</h3>
              <p className="text-slate-300">
                Prostadine is unlike anything you've ever tried or experienced in your life before. It's the only dropper that contains nine powerful natural ingredients that work in perfect synergy to keep your prostate healthy and mineral-free well into old age.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Ingredients Section */}
      <section id="ingredients" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4 text-center">
            Inside Every Drop of Prostadine
          </h2>
          <p className="text-center text-slate-300 mb-12 text-lg">
            100% natural and unique ingredients that are clinically proven
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                name: "Nori Yaki Extract Powder",
                benefits: ["Supports prostate repair", "Maintains healthy urinary system"],
              },
              {
                name: "Wakame Extract",
                benefits: ["Supports normal function of the bladder", "Strong antibacterial properties"],
              },
              {
                name: "Kelp Powder",
                benefits: ["Keeps the system toxin-free", "Supports a strong urine flow"],
              },
              {
                name: "Bladderwrack Powder",
                benefits: ["Strengthens prostate cells", "Supports healthy libido levels"],
              },
              {
                name: "Saw Palmetto",
                benefits: ["Kidney supporting properties", "Strong antimicrobial"],
              },
              {
                name: "Pomegranate Extract",
                benefits: ["Maintains healthy blood flow", "Supports testosterone levels"],
              },
              {
                name: "Iodine",
                benefits: ["Supports the urinary tract", "Maintains healthy prostate function"],
              },
              {
                name: "Shilajit",
                benefits: ["Strong antioxidant benefits", "Sleep supporting properties"],
              },
              {
                name: "Neem",
                benefits: ["Strong antioxidant benefits", "Sleep supporting properties"],
              },
            ].map((ingredient, idx) => (
              <div
                key={idx}
                className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-400 transition"
              >
                <h4 className="text-lg font-bold mb-4 text-blue-400">{ingredient.name}</h4>
                <ul className="space-y-2">
                  {ingredient.benefits.map((benefit, i) => (
                    <li key={i} className="flex gap-2 text-slate-300">
                      <Check className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6 text-center">
            {[
              "Natural Formula",
              "Plant Ingredients",
              "Non-GMO",
              "No Stimulants",
              "Easy To Use",
            ].map((feature, idx) => (
              <div key={idx} className="p-4">
                <div className="text-3xl mb-2">✓</div>
                <p className="font-semibold text-slate-300">{feature}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonuses Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">
            Order 6 Bottles and Get 2 FREE Bonuses!
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-400/30 rounded-lg p-8">
              <h3 className="text-2xl font-bold mb-2">Bonus #1</h3>
              <p className="text-green-400 font-semibold mb-4">
                Kidney Restore: 2-Day Flash Detox at Home
              </p>
              <p className="text-slate-300 mb-4">
                Retail Price: <span className="line-through">$79</span>
              </p>
              <p className="text-2xl font-bold text-green-400 mb-4">Today: FREE</p>
              <p className="text-slate-300">
                Kickstart your Prostadine journey and start cleansing your kidneys naturally with 7 unexpected spice and herb mixes from your kitchen.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-400/30 rounded-lg p-8">
              <h3 className="text-2xl font-bold mb-2">Bonus #2</h3>
              <p className="text-purple-400 font-semibold mb-4">
                Rockstar Libido in 7 Days
              </p>
              <p className="text-slate-300 mb-4">
                Retail Price: <span className="line-through">$79</span>
              </p>
              <p className="text-2xl font-bold text-purple-400 mb-4">Today: FREE</p>
              <p className="text-slate-300">
                Learn how to turn plain water into the most powerful natural remedy and boost your stamina up to 41%.
              </p>
            </div>
          </div>

          <div className="text-center bg-slate-800/50 rounded-lg p-8 border border-slate-700">
            <p className="text-xl font-semibold mb-2">Every 6 Bottles Order Gets</p>
            <p className="text-3xl font-bold text-green-400">FREE Shipping!</p>
            <p className="text-slate-400 mt-4">*97% of customers order 6 bottles (Our recommended option)</p>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">
            Real Prostadine Users. Real Life-Changing Results.
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Tom Stevenson",
                location: "New York, USA",
                quote:
                  "I can't believe how much this has changed my life! I'm a widower and thanks to your formula, I can finally start socializing and dating again.",
              },
              {
                name: "James Richards",
                location: "Wyoming, USA",
                quote:
                  "I am so grateful this product exists, my life is so much easier, I finally feel like myself again!",
              },
              {
                name: "Charlie Williams",
                location: "Chicago, USA",
                quote:
                  "I cannot tell you how much this has helped me with my self-esteem. I am a confident man once again.",
              },
            ].map((testimonial, idx) => (
              <div
                key={idx}
                className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-400 transition"
              >
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 fill-yellow-400 text-yellow-400"
                    />
                  ))}
                </div>
                <p className="text-slate-300 mb-6 italic">"{testimonial.quote}"</p>
                <p className="font-bold text-blue-400">{testimonial.name}</p>
                <p className="text-slate-400 text-sm">{testimonial.location}</p>
                <p className="text-green-400 text-sm mt-2">✓ Verified Purchase</p>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <div className="inline-block bg-slate-800/50 border border-slate-700 rounded-lg px-6 py-4">
              <p className="text-2xl font-bold">⭐ 4.9/5</p>
              <p className="text-slate-400">based on 19,651 reviews</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-4 text-center">
            Claim Your Discounted Prostadine Below While Stocks Last!
          </h2>
          <p className="text-center text-slate-300 mb-12">Limited time offer</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {[
              {
                bottles: "1",
                supply: "30 Day Supply",
                originalPrice: "$99",
                price: "$69",
                highlighted: false,
              },
              {
                bottles: "3",
                supply: "90 Day Supply",
                originalPrice: "$297",
                price: "$177",
                highlighted: false,
              },
              {
                bottles: "6",
                supply: "180 Day Supply",
                originalPrice: "$594",
                price: "$294",
                highlighted: true,
                shipping: "FREE Shipping",
              },
            ].map((plan, idx) => (
              <div
                key={idx}
                className={`rounded-lg p-8 border transition ${
                  plan.highlighted
                    ? "bg-gradient-to-br from-blue-500/20 to-purple-500/20 border-blue-400 scale-105"
                    : "bg-slate-800/50 border-slate-700 hover:border-blue-400"
                }`}
              >
                {plan.highlighted && (
                  <div className="text-center mb-4">
                    <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-bold">
                      BEST VALUE
                    </span>
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-2">{plan.bottles}x Bottle</h3>
                <p className="text-slate-400 mb-4">· {plan.supply} ·</p>
                <p className="text-slate-400 line-through mb-2">{plan.originalPrice}</p>
                <p className="text-4xl font-bold text-blue-400 mb-4">{plan.price}</p>
                {plan.shipping && (
                  <p className="text-green-400 font-semibold mb-6">{plan.shipping}</p>
                )}
                <Button
                  onClick={handleCookieChoice}
                  className={`w-full py-3 rounded-lg font-bold ${
                    plan.highlighted
                      ? "bg-blue-600 hover:bg-blue-700 text-white"
                      : "bg-slate-700 hover:bg-slate-600 text-white"
                  }`}
                >
                  Order Now
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Guarantee Section */}
      <section className="py-20 bg-slate-800/50">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-4xl font-bold mb-6">
              100% Satisfaction 60-Day Money Back Guarantee
            </h2>
            <p className="text-lg text-slate-300 mb-8">
              Your order today is covered by our iron-clad 60-day 100% money-back guarantee. If you are not impressed with the results, then at any time in the next 60 days write to us and we'll refund every single cent.
            </p>
            <Button
              onClick={handleCookieChoice}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-lg"
            >
              Get Started Now
            </Button>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">
            Frequently Asked Questions
          </h2>

          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                question: "How and why does Prostadine work?",
                answer:
                  "Prostadine contains nine powerful natural ingredients that have been perfectly combined to support a healthy prostate, kidneys and urinary tract well into old age, while withstanding any threat or external attack that might compromise their normal functioning.",
              },
              {
                question: "Is Prostadine right for me?",
                answer:
                  "All of the ingredients inside of Prostadine have been constantly tested for purity and to ensure against toxins and contaminants. With more than 160,000 customers, we haven't seen any notable side effects. If you currently have a medical condition or you're taking other prescription medication, we advise you to show a bottle of Prostadine to your doctor before you take it.",
              },
              {
                question: "When and how should I take Prostadine?",
                answer:
                  "We recommend you take two full droppers (2 ml) per day, preferably in the morning. You can pour it directly into your mouth or put it into your tea, coffee, juice or any other beverage you enjoy. Just make sure to shake the bottle well first.",
              },
              {
                question: "Can you tell me about the guarantee again?",
                answer:
                  "Every bottle of Prostadine comes with an ironclad 60-day money back guarantee. If, for any reason, you aren't fully satisfied with the results, you can just return what you haven't used for a full, no question asked refund.",
              },
            ].map((faq, idx) => (
              <div
                key={idx}
                className="bg-slate-800/50 border border-slate-700 rounded-lg p-6 hover:border-blue-400 transition"
              >
                <h3 className="text-lg font-bold text-blue-400 mb-3">
                  {faq.question}
                </h3>
                <p className="text-slate-300">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900/80 border-t border-slate-700 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400">
                    About Prostadine
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400">
                    Ingredients
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400">
                    Contact
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400">
                    Terms of Use
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400">
                    Privacy Policy
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Policies</h4>
              <ul className="space-y-2 text-slate-400 text-sm">
                <li>
                  <a href="#" className="hover:text-blue-400">
                    Shipping Policy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-blue-400">
                    Refund Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-700 pt-8 text-center text-slate-400 text-sm">
            <p className="mb-2">
              © 2025 Prostadine. All Rights Reserved. | Powered by Manus
            </p>
            <p>
              Statements on this website have not been evaluated by the Food and
              Drug Administration. Products are not intended to diagnose, treat,
              cure or prevent any disease.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
